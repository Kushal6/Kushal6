(function(){
  // ---- scroll-linked 3D nut and bolt ----
  function initBackgroundBolt(){
    const canvas = document.getElementById('backgroundBoltCanvas');
    if(!canvas || typeof THREE === 'undefined') return null;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(34, window.innerWidth / window.innerHeight, .1, 100);
    const renderer = new THREE.WebGLRenderer({ canvas, antialias:true, alpha:true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.5));
    renderer.setSize(window.innerWidth, window.innerHeight);

    const assembly = new THREE.Group();
    const bolt = new THREE.Group();
    const nut = new THREE.Group();
    assembly.add(bolt, nut);
    scene.add(assembly);

    const steel = new THREE.MeshStandardMaterial({ color:0x50657a, metalness:.88, roughness:.22, transparent:true, opacity:.82 });
    const brass = new THREE.MeshStandardMaterial({ color:0xb07b2c, metalness:.78, roughness:.24, transparent:true, opacity:.88 });
    scene.add(new THREE.HemisphereLight(0xd9e8f2, 0x1c2b3b, 1.7));
    const keyLight = new THREE.DirectionalLight(0xffd28b, 2.4);
    keyLight.position.set(4, 6, 7);
    scene.add(keyLight);
    const shaft = new THREE.Mesh(new THREE.CylinderGeometry(.3, .3, 4.4, 24), steel);
    shaft.position.y = -1.1;
    bolt.add(shaft);
    const head = new THREE.Mesh(new THREE.CylinderGeometry(.78, .78, .42, 6, 1, false, 0, Math.PI * 2), brass);
    head.position.y = 1.2;
    bolt.add(head);

    const outer = new THREE.Shape();
    for(let i=0;i<6;i++){
      const angle = (i / 6) * Math.PI * 2 + Math.PI / 6;
      const point = new THREE.Vector2(Math.cos(angle) * .95, Math.sin(angle) * .95);
      if(i === 0) outer.moveTo(point.x, point.y); else outer.lineTo(point.x, point.y);
    }
    outer.closePath();
    const hole = new THREE.Path();
    hole.absarc(0, 0, .43, 0, Math.PI * 2, false);
    outer.holes.push(hole);
    const nutGeometry = new THREE.ExtrudeGeometry(outer, { depth:.55, bevelEnabled:true, bevelThickness:.07, bevelSize:.05, bevelSegments:2, curveSegments:8 });
    nutGeometry.center();
    const nutMesh = new THREE.Mesh(nutGeometry, brass);
    nutMesh.rotation.x = Math.PI / 2;
    nut.add(nutMesh);
    nut.position.y = .55;

    camera.position.set(6, 3.6, 9);
    camera.lookAt(0, 0, 0);
    assembly.position.set(0, .2, 0);
    assembly.rotation.z = -.12;
    const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    let scrollProgress = 0;
    let frameId;

    function update(progress){
      scrollProgress = progress;
      if(reduced) return;
      nut.position.y = .55 - progress * 2.1;
      nut.rotation.y = -progress * Math.PI * 3.2;
      nut.rotation.z = progress * .35;
      bolt.rotation.y = -progress * .8;
      assembly.rotation.x = -.08 + progress * .3;
    }
    function animate(){
      frameId = requestAnimationFrame(animate);
      if(!reduced) assembly.rotation.y += .002;
      renderer.render(scene, camera);
    }
    animate();

    window.addEventListener('resize', () => {
      camera.aspect = window.innerWidth / window.innerHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(window.innerWidth, window.innerHeight);
      assembly.position.x = 0;
    });
    return { update };
  }
  const backgroundBolt = initBackgroundBolt();

  // ---- 3D hero scene ----
  function initHero3D(){
    const wrap = document.getElementById('heroCanvasWrap');
    const canvas = document.getElementById('heroCanvas');
    if(!wrap || !canvas || typeof THREE === 'undefined') return;

    const scene = new THREE.Scene();
    const camera = new THREE.PerspectiveCamera(42, wrap.clientWidth / wrap.clientHeight, 0.1, 100);
    const renderer = new THREE.WebGLRenderer({ canvas, antialias:true, alpha:true });
    renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 2));
    renderer.setSize(wrap.clientWidth, wrap.clientHeight);

    const group = new THREE.Group();
    scene.add(group);

    const amber = 0xE8A33D, blue = 0x5E8CAE, dim = 0x5A6A88;

    function addBlock(w,h,d,x,z,color,opacity){
      const geo = new THREE.BoxGeometry(w,h,d);
      const edges = new THREE.EdgesGeometry(geo);
      const mat = new THREE.LineBasicMaterial({ color, transparent:true, opacity: opacity || 0.9 });
      const seg = new THREE.LineSegments(edges, mat);
      seg.position.set(x, h/2, z);
      group.add(seg);
      // faint floor slabs for a "structural frame" read
      const slabCount = Math.max(1, Math.floor(h / 0.9));
      for(let i=1;i<slabCount;i++){
        const slabGeo = new THREE.EdgesGeometry(new THREE.BoxGeometry(w*0.98,0.001,d*0.98));
        const slabMat = new THREE.LineBasicMaterial({ color: dim, transparent:true, opacity:0.35 });
        const slab = new THREE.LineSegments(slabGeo, slabMat);
        slab.position.set(x, (i/slabCount)*h, z);
        group.add(slab);
      }
      return seg;
    }

    addBlock(2.1, 4.6, 2.1, -2.1, 0, blue, 0.95);
    addBlock(1.5, 3.0, 1.5, 0.7, 1.3, amber, 0.95);
    addBlock(2.6, 1.8, 2.6, 2.6, -1.1, dim, 0.8);

    const grid = new THREE.GridHelper(14, 14, 0x2C3B57, 0x2C3B57);
    grid.material.transparent = true;
    grid.material.opacity = 0.4;
    scene.add(grid);

    camera.position.set(6.2, 4.6, 8.4);
    camera.lookAt(0, 1.8, 0);

    let mouseX = 0, mouseY = 0, autoRot = 0.35;
    const reduced = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;

    wrap.addEventListener('mousemove', (e) => {
      const r = wrap.getBoundingClientRect();
      mouseX = ((e.clientX - r.left) / r.width - 0.5) * 2;
      mouseY = ((e.clientY - r.top) / r.height - 0.5) * 2;
    });
    wrap.addEventListener('mouseleave', () => { mouseX = 0; mouseY = 0; });
    wrap.addEventListener('touchmove', (e) => {
      if(!e.touches[0]) return;
      const r = wrap.getBoundingClientRect();
      mouseX = ((e.touches[0].clientX - r.left) / r.width - 0.5) * 2;
      mouseY = ((e.touches[0].clientY - r.top) / r.height - 0.5) * 2;
    }, { passive:true });

    let frameId;
    function animate(){
      frameId = requestAnimationFrame(animate);
      if(!reduced) autoRot += 0.0022;
      group.rotation.y += ((autoRot + mouseX * 0.35) - group.rotation.y) * 0.06;
      camera.position.x = 6.2 + mouseX * 1.4;
      camera.position.y = 4.6 - mouseY * 1.1;
      camera.lookAt(0, 1.8, 0);
      renderer.render(scene, camera);
    }
    animate();

    window.addEventListener('resize', () => {
      if(!wrap.clientWidth) return;
      camera.aspect = wrap.clientWidth / wrap.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(wrap.clientWidth, wrap.clientHeight);
    });

    document.addEventListener('visibilitychange', () => {
      if(document.hidden) cancelAnimationFrame(frameId);
      else animate();
    });
  }
  initHero3D();

  // ---- 3D tilt on project cards ----
  document.querySelectorAll('.project').forEach(card => {
    card.addEventListener('mousemove', (e) => {
      const r = card.getBoundingClientRect();
      const px = (e.clientX - r.left) / r.width - 0.5;
      const py = (e.clientY - r.top) / r.height - 0.5;
      card.style.transform = 'perspective(900px) rotateY(' + (px*9) + 'deg) rotateX(' + (-py*9) + 'deg) scale(1.015)';
    });
    card.addEventListener('mouseleave', () => { card.style.transform = ''; });
  });

  // header shrink
  const header = document.getElementById('siteHeader');
  const reducedMotion = window.matchMedia && window.matchMedia('(prefers-reduced-motion: reduce)').matches;
  window.addEventListener('scroll', () => {
    header.classList.toggle('scrolled', window.scrollY > 40);
    const progress = Math.min(1, window.scrollY / Math.max(1, document.documentElement.scrollHeight - window.innerHeight));
    if(backgroundBolt && !reducedMotion) backgroundBolt.update(progress);
  }, { passive:true });

  // reveal on scroll
  const revealEls = document.querySelectorAll('.reveal');
  const io = new IntersectionObserver((entries) => {
    entries.forEach(e => {
      if(e.isIntersecting){ e.target.classList.add('in'); io.unobserve(e.target); }
    });
  }, { threshold:0.15 });
  revealEls.forEach(el => io.observe(el));

  // animated counters
  const counters = document.querySelectorAll('.stat .count');
  let countersFired = false;
  const statRow = document.getElementById('statRow');
  if(statRow){
    const cio = new IntersectionObserver((entries) => {
      entries.forEach(e => {
        if(e.isIntersecting && !countersFired){
          countersFired = true;
          counters.forEach(c => {
            const target = parseFloat(c.getAttribute('data-target'));
            const isDecimal = target % 1 !== 0;
            const numEl = c.querySelector('.n');
            const dur = 1400;
            const start = performance.now();
            function tick(now){
              const p = Math.min(1, (now - start) / dur);
              const eased = 1 - Math.pow(1 - p, 3);
              const val = target * eased;
              numEl.textContent = isDecimal ? val.toFixed(1) : Math.round(val);
              if(p < 1) requestAnimationFrame(tick);
            }
            requestAnimationFrame(tick);
          });
        }
      });
    }, { threshold:0.4 });
    cio.observe(statRow);
  }

  // process scroll-linked line + active step
  const steps = document.querySelectorAll('.process-step');
  const fill = document.getElementById('processFill');
  const processEl = document.querySelector('.process');
  function updateProcess(){
    if(!processEl) return;
    const rect = processEl.getBoundingClientRect();
    const vh = window.innerHeight;
    const total = rect.height;
    let progress = (vh * 0.75 - rect.top) / total;
    progress = Math.max(0, Math.min(1, progress));
    fill.style.height = (progress * 100) + '%';
    steps.forEach((s, i) => {
      const threshold = i / steps.length;
      s.classList.toggle('active', progress > threshold + 0.05);
    });
  }
  window.addEventListener('scroll', updateProcess, { passive:true });
  window.addEventListener('resize', updateProcess);
  updateProcess();

  // mobile nav toggle (simple show/hide fallback)
  const navToggle = document.getElementById('navToggle');
  const navlinks = document.querySelector('.navlinks');
  if(navToggle){
    navToggle.addEventListener('click', () => {
      const open = navlinks.style.display === 'flex';
      navlinks.style.display = open ? 'none' : 'flex';
      navlinks.style.flexDirection = 'column';
      navlinks.style.position = 'fixed';
      navlinks.style.top = '64px';
      navlinks.style.right = '22px';
      navlinks.style.background = 'var(--bg)';
      navlinks.style.border = '1px solid var(--hairline)';
      navlinks.style.padding = '20px';
      navlinks.style.gap = '18px';
      navlinks.style.zIndex = '160';
    });
  }

  // contact form: validate client-side, then submit for real to FormSubmit.co
  // First-ever submission triggers a one-time activation email to the inbox above —
  // that link must be clicked once before submissions start arriving automatically.
  const form = document.getElementById('quoteForm');
  const status = document.getElementById('formStatus');

  // show a thank-you state if we've just bounced back from FormSubmit
  if(window.location.search.includes('sent=true') && status){
    status.textContent = '✓ Request sent — we\'ll be in touch within one business day.';
    status.classList.add('ok');
    history.replaceState(null, '', window.location.pathname + window.location.hash);
  }

  if(form){
    form.addEventListener('submit', (e) => {
      let valid = true;
      const fields = [
        { id:'name', check: v => v.trim().length > 1, msg:'Please enter your name.' },
        { id:'email', check: v => /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(v), msg:'Please enter a valid email.' },
        { id:'message', check: v => v.trim().length > 8, msg:'Tell us a bit more about the project.' }
      ];
      fields.forEach(f => {
        const el = document.getElementById(f.id);
        const errEl = form.querySelector('[data-error-for="' + f.id + '"]');
        if(!f.check(el.value)){
          valid = false;
          if(errEl) errEl.textContent = f.msg;
          el.style.borderBottomColor = '#C0552E';
        } else {
          if(errEl) errEl.textContent = '';
          el.style.borderBottomColor = '';
        }
      });
      if(!valid){
        e.preventDefault();
        status.textContent = 'Please check the highlighted fields.';
        status.classList.remove('ok');
        return;
      }
      // valid — let the browser submit the form to FormSubmit for real
      status.textContent = 'Sending…';
      status.classList.remove('ok');
    });
  }
})();
