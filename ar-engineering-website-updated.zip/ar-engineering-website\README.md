# A.R Engineering Consultancy & Construction — Website

A premium, animated marketing site for A.R Engineering Consultancy and
Construction Company, built as plain HTML/CSS/JS (no build step, no
framework required).

## Files

| File         | What it is                                              |
|--------------|----------------------------------------------------------|
| `index.html` | Page markup — structure and content                     |
| `style.css`  | All styling (Harbour Navy / warm sand / soft gold theme) |
| `script.js`  | Animations, scroll reveals, the 3D hero scene, form logic|

Open `index.html` in a browser (or upload all three files to any static
host — Netlify, Vercel, GitHub Pages, cPanel, etc.) and the site works
as-is. It needs no server, database, or build tools.

## Fonts & libraries used

Loaded from public CDNs, referenced directly in `index.html`:
- Google Fonts — Space Grotesk, IBM Plex Sans, IBM Plex Mono
- Three.js r128 (`cdnjs.cloudflare.com`) — powers the rotating 3D
  wireframe model in the hero

If you move this to a fully offline / air-gapped environment, download
those two resources locally and update the `<link>`/`<script>` tags in
`index.html` to point at your own copies.

## The "Request a Quote" form

The contact form at the bottom of the page submits to
[FormSubmit](https://formsubmit.co) — a free service that forwards
form submissions to an email inbox with **no backend or signup
required** on your side.

Current destination inbox (set in `index.html`, on the `<form>` tag's
`action` attribute):

```
kushalkhadka1240@hmail.com
```

**⚠️ Double check this address.** `hmail.com` is not a common domain —
if this was meant to be `gmail.com` (or something else), messages will
bounce and you will never see them. Fix it by editing the `action`
attribute on the `<form>` in `index.html`:

```html
<form ... action="https://formsubmit.co/YOUR-EMAIL-HERE" method="POST">
```

### One-time activation

The **first** time anyone submits the form after you change (or first
set) the address, FormSubmit sends a confirmation email to that inbox.
Someone must open that email and click the confirmation link once —
after that, every future submission is delivered automatically with no
further action needed.

### Changing where confirmations redirect to

After a successful submission, FormSubmit redirects the visitor back
to the URL set in this hidden field inside the form:

```html
<input type="hidden" name="_next" value="...">
```

Update it to point at wherever you end up hosting the site, with
`?sent=true#contact` appended, so the page shows its own "Request
sent" confirmation message instead of FormSubmit's generic page.

## Customizing

- **Colors** — CSS custom properties at the top of `style.css`
  (`:root { --navy: ...; --amber: ...; --paper: ...; }`) control the
  whole palette in one place.
- **Copy** — all text lives directly in `index.html`; there's no CMS
  or data file.
- **Company details** (address, phone, hours) — in the "Contact"
  section of `index.html`, inside the `<dl>` element.

## Notes

- The hero's rotating wireframe model, scroll-triggered stat counters,
  and scroll-linked process timeline are all in `script.js` and respect
  `prefers-reduced-motion`.
- No analytics, tracking, or cookies are included.
